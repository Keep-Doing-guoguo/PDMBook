 import matplotlib
 font = {
     'family': 'SimHei',
     'size': 20    
 }
 matplotlib.rc('font', **font)
 
 import pandas

 data = pandas.read_csv(
     'D:\\PDMBook\\第二章 回归模型\\2.3 多元线性回归分析\\线性回归.csv',
     engine='python', encoding='utf8'
 )
 #定义自变量
 x = data[["广告费用(万元)", "客流量(万人次)"]]
 #定义因变量
 y = data[["销售额(万元)"]]

 #计算相关系数
 data['广告费用(万元)'].corr(data['销售额(万元)'])
 data['客流量(万人次)'].corr(data['销售额(万元)'])

 #广告费用   作为 x 轴
 #销售额     作为 y 轴，绘制散点图
 data.plot('广告费用(万元)', '销售额(万元)', kind='scatter')
 #客流量     作为 x 轴
 #销售额     作为 y 轴，绘制散点图
 data.plot('客流量(万人次)', '销售额(万元)', kind='scatter')

 #导入sklearn.linear_model模块中的LinearRegression函数
 from sklearn.linear_model import LinearRegression 
 #使用线性回归模型进行建模
 lrModel = LinearRegression()
 #使用自变量 x 和因变量 y 训练模型
 lrModel.fit(x, y)

 #查看参数
 lrModel.coef_

 #查看截距
 lrModel.intercept_

 #计算模型的精度
 lrModel.score(x, y)

 #生成预测所需的自变量数据框
 pX = pandas.DataFrame({
     '广告费用(万元)': [20],
     '客流量(万人次)': [5]
 })
 #对未知的数据进行预测
 lrModel.predict(pX)

