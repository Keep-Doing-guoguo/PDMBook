 import matplotlib
 
 font = {
     'family': 'SimHei',
     'size': 20    
 }
 matplotlib.rc('font', **font)
  
 import pandas

 data = pandas.read_csv(
     'D:\\PDMBook\\第二章 回归模型\\2.2 简单线性回归分析\\线性回归.csv',
     engine='python', encoding='utf8'
 )
 #定义自变量
 x = data[["广告费用(万元)"]]
 #定义因变量
 y = data[["销售额(万元)"]]

 #计算相关系数
 data['广告费用(万元)'].corr(data['销售额(万元)'])

 #广告费用  作为 x 轴
 #销售额    作为 y 轴，绘制散点图
 data.plot('广告费用(万元)', '销售额(万元)', kind='scatter')
 
 #导入sklearn.linear_model模块中的LinearRegression函数
 from sklearn.linear_model import LinearRegression 
 #使用线性回归模型进行建模
 lrModel = LinearRegression()
 #使用自变量 x 和因变量 y 训练模型
 lrModel.fit(x, y)

 #查看参数
 lrModel.coef_

 #查看截距
 lrModel.intercept_

 data['预测销售额'] = lrModel.predict(x)
 data['销售额(万元)'].corr(data.预测销售额)
 data['销售额(万元)'].corr(data.预测销售额)**2

 #计算模型的精度
 lrModel.score(x, y)
 
 #生成预测所需的自变量数据框
 pX = pandas.DataFrame({
     '广告费用(万元)': [20]
 })
 #对未知的数据进行预测
 lrModel.predict(pX)


import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

font = FontProperties(
    fname="C:\\windows\\fonts\\msyh.ttc", size=20
)
#绘图
plt.figure()
plt.title('广告费用与销售额', fontproperties=font)
plt.xlabel('广告费用(万元)', fontproperties=font)
plt.ylabel('销售额(万元)', fontproperties=font)
plt.scatter(x, y, s=100)
import numpy
xs = pandas.DataFrame({
     '广告费用(万元)':numpy.arange(10, 30, 0.1)
})
ys = lrModel.predict(xs)
plt.plot(xs, ys, linewidth=5)
plt.show()
