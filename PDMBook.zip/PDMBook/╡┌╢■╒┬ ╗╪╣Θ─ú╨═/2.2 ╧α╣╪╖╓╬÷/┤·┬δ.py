 import pandas

 data = pandas.read_csv(
     'D:\\PDMBook\\第二章 回归模型\\2.1 相关分析\\相关分析.csv',
     engine='python', encoding='utf8'
 )

 data['人口'].corr(data['文盲率'])

 data[[
     '超市购物率', '网上购物率', '文盲率', '人口'
 ]].corr()

 #计算多列的相关系数，
 #可以使用两个中括号，即从数据框里面选择多列的数据，
 #形成新的数据框，再调用corr函数
 corrMatrix = data[[
     '超市购物率', '网上购物率', '文盲率', '人口'
 ]].corr()
 
 