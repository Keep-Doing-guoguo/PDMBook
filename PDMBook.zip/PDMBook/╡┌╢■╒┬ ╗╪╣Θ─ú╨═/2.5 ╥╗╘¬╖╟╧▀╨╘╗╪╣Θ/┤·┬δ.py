# -*- coding: utf-8 -*-

import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第二章 回归模型\\2.4 一元非线性回归\\一元非线性回归.csv',
    engine='python', encoding='utf8'
)

x = data[["发布天数"]]
y = data[["活跃用户数"]]

import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

font = FontProperties(
    fname="D:\\PDMBook\\SourceHanSansCN-Light.otf", 
    size=25
)

#新建一个绘图窗口
plt.figure()
#设置图形标题
plt.title(
    '发布天数与活跃用户数', 
    fontproperties=font
)
#设置 x 轴标签
plt.xlabel(
    '发布天数', 
    fontproperties=font
)
#设置 y 轴标签
plt.ylabel(
    '活跃用户数', 
    fontproperties=font
)
plt.scatter(x, y)
plt.show()

#尝试二元线性回归
data['x0'] = data.发布天数.pow(0)
data['x1'] = data.发布天数.pow(1)
data['x2'] = data.发布天数.pow(2)

x = data[['x0', 'x1', 'x2']]
y = data[["活跃用户数"]]

from sklearn.linear_model import LinearRegression
lrModel = LinearRegression()
lrModel.fit(x, y)
lrModel.score(x, y)

data['x3'] = data.发布天数.pow(3)

x = data[['x0', 'x1', 'x2', 'x3']]
y = data[["活跃用户数"]]

from sklearn.linear_model import LinearRegression
lrModel = LinearRegression()
lrModel.fit(x, y)
lrModel.score(x, y)


from sklearn.preprocessing import PolynomialFeatures
polynomialFeatures = PolynomialFeatures(degree=4)
x = data[["发布天数"]]
x_4 = polynomialFeatures.fit_transform(x)


x = data[["发布天数"]]
ds = []
scores = []
for d in range(2, 20):
    ds.append(d)
    
    polynomialFeatures = PolynomialFeatures(degree=d)
    x_d = polynomialFeatures.fit_transform(x)

    lrModel = LinearRegression()
    lrModel.fit(x_d, y)
    
    scores.append(lrModel.score(x_d, y))

dScores = pandas.DataFrame({
    '阶次':ds,
    '模型得分': scores
})

#新建一个绘图窗口
plt.figure()
#设置图形标题
plt.title(
    '多项式阶次与模型得分', 
    fontproperties=font
)
#设置 x 轴标签
plt.xlabel(
    '多项式阶次', 
    fontproperties=font
)
#设置 y 轴标签
plt.ylabel(
    '模型得分', 
    fontproperties=font
)
plt.scatter(ds, scores)
plt.show()

x = data[["发布天数"]]
y = data[["活跃用户数"]]
polynomialFeatures = PolynomialFeatures(degree=3)
x_3 = polynomialFeatures.fit_transform(x)
lrModel = LinearRegression()
lrModel.fit(x_3, y)
lrModel.score(x_3, y)

px = pandas.DataFrame({
    '发布天数': [730]
})
px_3 = polynomialFeatures.transform(px)
lrModel.predict(px_3)