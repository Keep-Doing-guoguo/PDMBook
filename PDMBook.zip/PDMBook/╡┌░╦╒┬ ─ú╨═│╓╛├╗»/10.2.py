# -*- coding: utf-8 -*-
import jieba
from sklearn.base import TransformerMixin

#定义一个Transformer，用于中文分词
class CnCut(TransformerMixin):
    #构造函数，需要输出两个参数：
    #cn_column_name 要分词的列
    def __init__(self, cn_column_name):
        self.cn_column_name = cn_column_name
    #中文分词不需要训练，因此直接返回对象即可
    def fit(self, X, y=None):
        return self
    #在转换方法中，实现中文分词的逻辑
    def transform(self, X, y=None):
        data = X.copy()
        fileContents = []
        for index, row in data.iterrows():
            fileContent = row[self.cn_column_name]
            segs = jieba.cut(fileContent)
            fileContents.append(" ".join(segs))
        data[self.cn_column_name] = fileContents
        return data[self.cn_column_name]

import pandas
#导入多项式文本分类的案例数据
data = pandas.read_excel(
    "D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\\多项式贝叶斯.xlsx"
)
#新建一个中文分词转换器
cnCut = CnCut(cn_column_name='fileContent')
#进行中文分词的转换
cutData = cnCut.transform(data)


#新建一个中文分词转换器
cnCut = CnCut(cn_column_name='fileContent')

from sklearn.feature_extraction.text import CountVectorizer
#新建一个文本向量化转换器
countVectorizer = CountVectorizer(
    min_df=0, token_pattern=r"\b\w+\b"
)

from sklearn.naive_bayes import MultinomialNB
#新建一个多项式朴素贝叶斯模型
MNBModel = MultinomialNB()

import pandas
#导入多项式文本分类的案例数据
data = pandas.read_excel(
    "D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\\多项式贝叶斯.xlsx"
)

#中文分词
cutData = cnCut.transform(data)
#训练文本向量化转换器
countVectorizer.fit(cutData)
#文本向量化
textVector = countVectorizer.transform(cutData)
#训练多项式朴素贝叶斯模型
MNBModel.fit(textVector, data['class'])
#对模型进行评分
MNBModel.score(textVector, data['class'])



from sklearn.pipeline import Pipeline
from sklearn.naive_bayes import MultinomialNB
from sklearn.feature_extraction.text import CountVectorizer

pipeline = Pipeline([
    ('DP', CnCut(cn_column_name='fileContent')), 
    ('FP', CountVectorizer(min_df=0, token_pattern=r"\b\w+\b")),
    ('Model', MultinomialNB())
])

import pandas
#导入多项式文本分类的案例数据
data = pandas.read_excel(
    "D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\\多项式贝叶斯.xlsx"
)
pipeline.fit(data, data['class'])
pipeline.score(data, data['class'])

pipeline.predict(data)

