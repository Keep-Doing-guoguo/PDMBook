# -*- coding: utf-8 -*-

from sklearn import datasets

#加载iris数据集
iris = datasets.load_iris()
#定义特征与训练目标
X, y = iris.data, iris.target

from sklearn import svm
#使用SVC建立一个SVM模型
SVMModel = svm.SVC()
#训练模型
SVMModel.fit(X, y)  

from sklearn.externals import joblib
#保存模型到SVMModel.sklearn文件中
joblib.dump(
    SVMModel, 
    'D:\\PDMBook\\第八章 模型持久化\\SVMModel.sklearn'
)

#到这里，关闭console，重新启动一个console

from sklearn.externals import joblib
#从文件中加载模型
SVMModel = joblib.load(
    'D:\\PDMBook\\第八章 模型持久化\\SVMModel.sklearn'
)

from sklearn import datasets
#加载iris数据集
iris = datasets.load_iris()
#定义特征与训练目标
X, y = iris.data, iris.target

#使用模型对数据进行评分
SVMModel.score(X, y)
#使用模型对数据进行预测
Y = SVMModel.predict(X)

import pandas
#计算数据的混淆矩阵
pandas.crosstab(y, Y)