# -*- coding: utf-8 -*-

import jieba
import pandas

#导入多项式文本分类的案例数据
data = pandas.read_excel(
    "D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\\多项式贝叶斯.xlsx"
)
#进行中文分词
fileContents = []
for index, row in data.iterrows():
    fileContent = row['fileContent']
    segs = jieba.cut(fileContent)
    fileContents.append(" ".join(segs))
data['file_content_cut'] = fileContents

from sklearn.feature_extraction.text import CountVectorizer
#文本向量化
countVectorizer = CountVectorizer(
    min_df=0, token_pattern=r"\b\w+\b"
)
textVector = countVectorizer.fit_transform(
    data['file_content_cut']
)

from sklearn.naive_bayes import MultinomialNB
MNBModel = MultinomialNB()

from sklearn.model_selection import cross_val_score
#进行K折交叉验证
cvs = cross_val_score(
    MNBModel, 
    textVector, 
    data['class'], 
    cv=3
)
cvs.mean()















import re
#匹配中文的正则表达式
zhPattern = re.compile(u'[\u4e00-\u9fa5]+')
#中文分词，去除非中文字符
fileContents = []
for index, row in data.iterrows():
    fileContent = row['fileContent']
    segs = jieba.cut(fileContent)
    segments = []
    for seg in segs:
        if zhPattern.search(seg):
            segments.append(seg.strip())
    fileContents.append(" ".join(segments))
data['file_content_cut_cn'] = fileContents
#导入停用词表
stopwords = pandas.read_csv(
    "StopwordsCN.txt", 
    encoding='utf8'
)
#增加停用词表，去除停用词
countVectorizer = CountVectorizer(
    min_df=0, token_pattern=r"\b\w+\b",
    stop_words=list(stopwords.stopword.values)
)
textVector = countVectorizer.fit_transform(
    data['file_content_cut_cn']
)

from sklearn.naive_bayes import MultinomialNB
MNBModel = MultinomialNB()
#进行K折交叉验证
cvs = cross_val_score(
    MNBModel, 
    textVector, 
    data['class'], 
    cv=3
)
cvs.mean()

MNBModel.fit(textVector, data['class'])

MNBModel.score(textVector, data['class'])













MNBModel.fit(textVector, data['class'])

MNBModel.score(textVector, data['class'])

newTexts = ["""
据介绍，EliteBook 840 G4是一款采用14英寸1080p屏幕的商务笔记本，
硬件配置方面，
入门级的EliteBook 840 G4搭载Intel Core i3-7100处理器，
配备4GB内存和500GB机械硬盘，预装Windows 10操作系统。
高端机型可选择更大容量的内存和SSD固态硬盘。
机身四周提供了USB 3.0、USB-C、DisplayPort、15针迷你D-Sub，
支持蓝牙4.2和802.11ac Wi-Fi。
整机重1.48千克。
"""]

for i in range(len(newTexts)):
    newTexts[i] = " ".join(jieba.cut(newTexts[i]))

newTextVector = countVectorizer.transform(newTexts)

MNBModel.predict(newTextVector)
MNBModel.predict_proba(newTextVector)
MNBModel.classes_