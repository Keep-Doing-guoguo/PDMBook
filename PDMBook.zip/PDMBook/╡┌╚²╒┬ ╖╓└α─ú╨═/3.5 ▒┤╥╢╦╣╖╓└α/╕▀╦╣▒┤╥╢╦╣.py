# -*- coding: utf-8 -*-

import pandas
#读取数据到 data 变量中
data = pandas.read_csv(
    'D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\高斯贝叶斯.csv', 
    encoding='utf8', 
    engine='python'
)

features = [
    '注册时长', '营收收入', '成本'
]

#高斯贝叶斯
from sklearn.naive_bayes import GaussianNB
gaussianNB = GaussianNB()

from sklearn.model_selection import cross_val_score
#进行K折交叉验证
cvs = cross_val_score(
    gaussianNB, 
    data[features], 
    data['是否续约'], 
    cv=10
)
cvs.mean()

gaussianNB = GaussianNB()
#使用所有数据训练模型
gaussianNB.fit(data[features], data['是否续约'])
#对所有的数据进行预测
data['预测是否续约'] = gaussianNB.predict(data[features])
from sklearn.metrics import confusion_matrix
#计算混淆矩阵，labels参数，可由 gaussianNB.classes_ 得到
confusion_matrix(
    data['是否续约'], 
    data['预测是否续约'], 
    labels=['不续约', '续约']
)
