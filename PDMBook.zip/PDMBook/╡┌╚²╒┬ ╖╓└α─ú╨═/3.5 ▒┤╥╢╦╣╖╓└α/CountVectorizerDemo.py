import jieba
import pandas

#增加词权重，方便分词
jieba.add_word("书", freq=1000000)
jieba.add_word("篮球", freq=100000)
jieba.add_word("乒乓球", freq=100000)
#读取案例数据
data = pandas.read_csv("CountVectorizerDemo.csv")

data['text_cut'] = data.text.apply(
    lambda t: " ".join(jieba.cut(t))
)

from sklearn.feature_extraction.text import CountVectorizer
#新建文本计数向量化器
countVectorizer = CountVectorizer(
    min_df=0, token_pattern=r"\b\w+\b"
)
#训练文本计数向量化器
countVectorizer.fit(data['text_cut'])
#获取特征词字典
vocabulary = countVectorizer.vocabulary_
#按照顺序对词字典进行排序显示
sorted(vocabulary.items(), key=lambda x: x[1])
#把文本转换为文本向量
textVector = countVectorizer.transform(
    data['text_cut']
)
#输出显示文本向量
textVector.toarray()

