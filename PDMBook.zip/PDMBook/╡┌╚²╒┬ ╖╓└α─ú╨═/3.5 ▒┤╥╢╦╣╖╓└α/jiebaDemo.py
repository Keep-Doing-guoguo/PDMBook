# -*- coding: utf-8 -*-

import jieba

list(jieba.cut("我喜欢打高尔夫"))

#给“高尔夫”这个词，设置一个较高的权限
jieba.add_word("高尔夫", freq=1000000)

list(jieba.cut("我喜欢打高尔夫"))