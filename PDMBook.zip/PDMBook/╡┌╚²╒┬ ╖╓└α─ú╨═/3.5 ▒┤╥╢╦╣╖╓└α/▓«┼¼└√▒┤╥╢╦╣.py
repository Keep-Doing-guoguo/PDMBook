# -*- coding: utf-8 -*-

import pandas
#读取数据到 data 变量中
data = pandas.read_csv(
    'D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\议案投票.csv', 
    encoding='utf8', 
    engine='python'
)
#填充缺失值，把所有放弃投票的值填充为字符串None
data = data.fillna("None")
#所有的议题作为特征
features = [
    'Campaign Finance Overhaul',
    'Unemployment and Tax Benefits', 
    'Fiscal 2003 Budget Resolution',
    'Permanent Tax Cuts', 'Food Stamps', 
    'Nuclear Waste', 'Fiscal 2003 Defense Authorization', 
    'Abortions Overseas', 'Defense Authorization Recommitment', 
    'Welfare Renewal', 'Estate Tax Repeal', 
    'Married Couples Tax Relief', 'Late Term Abortion Ban', 
    'Homeland Sec/Union Memb', 'Homeland Sec/Civil Service Emp',
    'Homeland Sec/Whistleblower Protections', 'Andean Trade',
    'Abortion Service Refusals', 'Medical Malpractice Awards',
    'Military Support for UN Resolution'
]

from sklearn.preprocessing import OneHotEncoder
#新建独热编码器
oneHotEncoder = OneHotEncoder()
#训练独热编码器，得到转换规则
oneHotEncoder.fit(data[features])
#转换数据
oneHotData = oneHotEncoder.transform(data[features])

#伯努利贝叶斯
from sklearn.naive_bayes import BernoulliNB
BNBModel = BernoulliNB()

from sklearn.model_selection import cross_val_score
#进行K折交叉验证
cvs = cross_val_score(BNBModel, oneHotData, data['Party'], cv=10)
cvs.mean()

BNBModel = BernoulliNB()
#使用所有数据训练模型
BNBModel.fit(oneHotData, data['Party'])
#对所有的数据进行预测
data['Predict Party'] = BNBModel.predict(oneHotData)
from sklearn.metrics import confusion_matrix
#计算混淆矩阵，labels参数，可由 BNBModel.classes_ 得到
confusion_matrix(
    data['Party'], 
    data['Predict Party'], 
    labels=['D', 'R']
)

pandas.crosstab(data['Party'], data['Predict Party'])