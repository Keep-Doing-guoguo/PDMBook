# -*- coding: utf-8 -*-

import pandas

#读取案例数据到data变量
data = pandas.read_csv(
    'D:\\PDMBook\\第三章 分类模型\\3.5 贝叶斯分类\\LabelEncoder.csv', 
    encoding='utf8', engine='python'
)

from sklearn.preprocessing import OneHotEncoder
#新建独热编码器
oneHotEncoder = OneHotEncoder()
#训练独热编码器，得到转换规则
oneHotEncoder.fit(data)
#转换数据
oneHotData = oneHotEncoder.transform(data)
#查看独热编码后的数据
oneHotData.toarray()
