import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第三章 分类模型\\3.7 随机森林\\随机森林.csv', 
    encoding='utf8', 
    engine='python'
)

#需要进行OneHot处理的列
oneHotColumns = ['性别', '父母鼓励']
from sklearn.preprocessing import OneHotEncoder
#新建独热编码器
oneHotEncoder = OneHotEncoder(drop='first')
#训练独热编码器，得到转换规则
oneHotEncoder.fit(
    data[oneHotColumns]
)
#转换数据
oneHotData = oneHotEncoder.transform(
    data[oneHotColumns]
)

from scipy.sparse import hstack
#将独热编码所得的数据，和父母收入、IQ两列合并在一起
x = hstack([
    oneHotData, 
    data.父母收入.values.reshape(-1, 1), 
    data.IQ.values.reshape(-1, 1)
])

y = data["升学计划"]

from sklearn.ensemble import RandomForestClassifier

rfClassifier = RandomForestClassifier()

from sklearn.model_selection import GridSearchCV

#网格搜索，寻找最优参数
paramGrid = dict(
    max_depth=[1, 2, 3, 4, 5],
    criterion=['gini', 'entropy'],    
    max_leaf_nodes=[3, 5, 6, 7, 8],
    n_estimators=[10, 50, 100, 150, 200],
)

gridSearchCV = GridSearchCV(
    rfClassifier, paramGrid, 
    cv=10, verbose=1, n_jobs=10,
    return_train_score=True
)
grid = gridSearchCV.fit(x, y)

print('最好的得分是: %f' % grid.best_score_)
print('最好的参数是:')
for key in grid.best_params_.keys():
    print('%s=%s'%(key, grid.best_params_[key]))


#网格搜索，寻找最优参数
paramGrid = dict(
    max_depth=[4, 5, 6, 7, 8],
    criterion=['gini', 'entropy'],    
    max_leaf_nodes=[8, 9, 10, 11, 12],
    n_estimators=[20, 30, 40, 45, 50],
)

gridSearchCV = GridSearchCV(
    rfClassifier, paramGrid, 
    cv=10, verbose=1, n_jobs=10,
    return_train_score=True
)
grid = gridSearchCV.fit(x, y)

print('最好的得分是: %f' % grid.best_score_)
print('最好的参数是:')
for key in grid.best_params_.keys():
    print('%s=%s'%(key, grid.best_params_[key]))



#网格搜索，寻找最优参数
paramGrid = dict(
    max_depth=[5, 6, 7],
    criterion=['gini', 'entropy'],    
    max_leaf_nodes=[11, 12, 15, 20, 30],
    n_estimators=[50, 60, 70, 80, 90],
)

gridSearchCV = GridSearchCV(
    rfClassifier, paramGrid, 
    cv=10, verbose=1, n_jobs=10,
    return_train_score=True
)
grid = gridSearchCV.fit(x, y)

print('最好的得分是: %f' % grid.best_score_)
print('最好的参数是:')
for key in grid.best_params_.keys():
    print('%s=%s'%(key, grid.best_params_[key]))
    
    
    
    
    
    
    
    
    
#网格搜索，寻找最优参数
paramGrid = dict(
    max_depth=[6, 7, 8],
    criterion=['gini', 'entropy'],    
    max_leaf_nodes=[30, 40, 50],
    n_estimators=[40, 50, 60],
)

gridSearchCV = GridSearchCV(
    rfClassifier, paramGrid, 
    cv=3, verbose=1, n_jobs=5,
    return_train_score=True
)
grid = gridSearchCV.fit(x, y)

print('最好的得分是: %f' % grid.best_score_)
print('最好的参数是:')
for key in grid.best_params_.keys():
    print('%s=%s'%(key, grid.best_params_[key]))

