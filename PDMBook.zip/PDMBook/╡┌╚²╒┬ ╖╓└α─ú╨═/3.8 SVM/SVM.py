# -*- coding: utf-8 -*-

import scipy.io as scio

wineData = scio.loadmat('D:\\PDM\\5.5\\data.mat')

wineData['categories']

fData = wineData['wine']
tData = wineData['wine_labels'].reshape(-1)
import pandas
data = pandas.DataFrame(
    fData, columns=['Alcohol',
'Malic acid',
'Ash',
'Alcalinity of ash',
'Magnesium',
'Total phenols',
'Flavanoids',
'Nonflavanoid phenols',
'Proanthocyanins',
'Color intensitys',
'Hue',
'OD280/OD315 of diluted wines',
'Proline']
)
data['label'] = wineData['wine_labels'].reshape(-1)
data.to_csv("SVM.csv", index=False)

import pandas
data = pandas.read_csv("SVM.csv")

x = data[[
    'Alcohol', 'Malic acid', 'Ash',
    'Alcalinity of ash','Magnesium',
    'Total phenols', 'Flavanoids',
    'Nonflavanoid phenols',
    'Proanthocyanins', 'Color intensitys',
    'Hue', 'OD280/OD315 of diluted wines',
    'Proline'
]]
y = data['label']

from sklearn.svm import SVC
from sklearn.model_selection import GridSearchCV

svc = SVC()
#网格搜索，寻找最优参数
paramGrid = dict(
    kernel=['poly'],
    degree=[5, 6, 7, 8]
)

gridSearchCV = GridSearchCV(
    svc, paramGrid, 
    cv=3, verbose=1, n_jobs=5,
    return_train_score=True
)
grid = gridSearchCV.fit(x, y)

print('最好的得分是: %f' % grid.best_score_)
print('最好的参数是:')
for key in grid.best_params_.keys():
    print('%s=%s'%(key, grid.best_params_[key]))



