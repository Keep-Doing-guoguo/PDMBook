# -*- coding: utf-8 -*-

import pandas
#读取数据
data = pandas.read_csv(
    '逻辑回归.csv', 
    encoding='utf8', 
    engine='python'
)
#删除缺失值
data = data.dropna()
# oneHot 特征列
oneHotColumns = [
    'Gender', 'Internet Connection', 'Marital Status',
    'Movie Selector', 'Prerec Format', 'TV Signal', 
    'Education Level', 'PPV Freq', 'Theater Freq', 
    'TV Movie Freq', 'Prerec Buying Freq', 
    'Prerec Renting Freq', 'Prerec Viewing Freq'
]

from sklearn.preprocessing import OneHotEncoder
#新建独热编码器
oneHotEncoder = OneHotEncoder()
#训练独热编码器，得到转换规则
oneHotEncoder.fit(data[oneHotColumns])
#转换数据
oneHotData = oneHotEncoder.transform(data[oneHotColumns])

#数值特征列
numericColumns = [
    'Age', 'Num Bathrooms', 
    'Num Bedrooms', 'Num Cars', 
    'Num Children', 'Num TVs'
]

from scipy.sparse import hstack
#合并 oneHot 特征与数值特征
x = hstack([
    oneHotData, 
    data[numericColumns].astype(float).values
])
#目标
y = data['Home Ownership']

from sklearn.linear_model import LogisticRegression
#逻辑回归模型
lrModel = LogisticRegression()

from sklearn.model_selection import cross_val_score
#进行K折交叉验证
cvs = cross_val_score(
    lrModel, 
    x, 
    y, 
    cv=10
)
cvs.mean()
