    import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第五章 聚类\\5.3 层次聚类\\层次聚类.csv',
    encoding='utf8', engine='python'
)

import matplotlib
import matplotlib.pyplot as plt
from pandas.plotting import scatter_matrix
#设置中文字体
font = matplotlib.font_manager.FontProperties(
    fname='D:\\PDMBook\\SourceHanSansCN-Light.otf', 
    size=15
)

fColumns = [
    '工作日上班时间人均停留时间', 
    '凌晨人均停留时间', 
    '周末人均停留时间', 
    '日均人流量'
]

from sklearn.preprocessing import scale
#因为人流量和时间属于不同的计量单位，
#因此需要对这份数据需要进行标准化
scaleData = pandas.DataFrame(
    scale(data[fColumns]), columns=fColumns
)

#绘制散点矩阵图
axes = scatter_matrix(
    scaleData, diagonal='hist'
)

#设置坐标轴的字体，避免坐标轴出现中文乱码
for ax in axes.ravel():
    ax.set_xlabel(
        ax.get_xlabel(), fontproperties=font
    )
    ax.set_ylabel(
        ax.get_ylabel(), fontproperties=font
    )


from sklearn.decomposition import PCA

pca_2 = PCA(n_components=2)
data_pca_2 = pandas.DataFrame(
    pca_2.fit_transform(scaleData)
)
plt.scatter(
    data_pca_2[0], 
    data_pca_2[1]
)


from sklearn.cluster import AgglomerativeClustering
#进行层次聚类，并预测样本的分组
agglomerativeClustering = AgglomerativeClustering(n_clusters=3)
pTarget = agglomerativeClustering.fit_predict(scaleData)

plt.figure()
plt.scatter(
    data_pca_2[0], 
    data_pca_2[1],
    c=pTarget
)

import scipy.cluster.hierarchy as hcluster
#构建层次聚类树
linkage = hcluster.linkage(
    scaleData, 
    method='centroid'
)
#绘制层次聚类图形
plt.figure()
hcluster.dendrogram(
    linkage,
    leaf_font_size=10.
)
#计算层次聚类结果
_pTarget = hcluster.fcluster(
    linkage, 3, 
    criterion='maxclust'
)



import seaborn as sns
from pandas.plotting import parallel_coordinates

fColumns = [
    '工作日上班时间人均停留时间', 
    '凌晨人均停留时间', 
    '周末人均停留时间', 
    '日均人流量',
    '类型'
]

data['类型'] = pTarget

plt.figure()    
ax = parallel_coordinates(
    data[fColumns], '类型', 
    color=sns.color_palette(),
)
#设置坐标轴的字体，避免坐标轴出现中文乱码
ax.set_xticklabels(
    ax.get_xticklabels(), fontproperties=font
)
ax.set_yticklabels(
    ax.get_yticklabels()
)
