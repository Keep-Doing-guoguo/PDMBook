# -*- coding: utf-8 -*-

import numpy
import pandas
import matplotlib.pyplot as plt

data = pandas.read_csv(
    'D:\\PDMBook\\第七章 时间序列分析\\非季节性时间序列.csv', 
    encoding='utf8', engine='python'
)

原始数据 = data['公司A']

#非季节性的时间序列，分解趋势部分和不规则部分
#SMA
移动平均 = 原始数据.rolling(3).mean()
plt.plot(
    data.index, 原始数据, 'k-', 
    data.index, 移动平均, 'g-'
)

随机误差 = 原始数据 - 移动平均
plt.plot(
    data.index, 原始数据, 'k-', 
    data.index, 移动平均, 'g-', 
    data.index, 随机误差, 'r-'
)


#WMA
#定义窗口大小
wl = 3
#定义每个窗口值的权重
ww = [1/6, 2/6, 3/6]

def wma(window):
    return numpy.sum(window*ww)

移动平均 = 原始数据.rolling(wl).aggregate(wma)

随机误差 = 原始数据 - 移动平均
plt.plot(
    data.index, 原始数据, 'k-', 
    data.index, 移动平均, 'g-', 
    data.index, 随机误差, 'r-'
)
