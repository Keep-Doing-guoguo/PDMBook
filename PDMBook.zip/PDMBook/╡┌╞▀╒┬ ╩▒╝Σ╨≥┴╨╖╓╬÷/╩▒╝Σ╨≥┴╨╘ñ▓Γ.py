# -*- coding: utf-8 -*-
import pandas
#导入时间序列数据
data = pandas.read_csv(
    'D:\\PDMBook\\第七章 时间序列分析\\时间序列预测.csv', 
    encoding='utf8', engine='python'
)
#设置索引为时间格式
data.index = pandas.to_datetime(
    data.date, format='%Y%m%d'
)
#删掉date列，因为它已经保存到索引中了
del data['date']

import matplotlib.pyplot as plt
#对数据进行绘图
plt.figure()
plt.plot(data, 'r')


import statsmodels.api as sm
import statsmodels.tsa.stattools as ts

#封装一个方法，方便解读 adfuller 函数的结果
def tagADF(t):
    result = pandas.DataFrame(index=[
            "Test Statistic Value", 
            "p-value", "Lags Used", 
            "Number of Observations Used", 
            "Critical Value(1%)", 
            "Critical Value(5%)", 
            "Critical Value(10%)"
        ], columns=['value']
    )
    result['value']['Test Statistic Value'] = t[0]
    result['value']['p-value'] = t[1]
    result['value']['Lags Used'] = t[2]
    result['value']['Number of Observations Used'] = t[3]
    result['value']['Critical Value(1%)'] = t[4]['1%']
    result['value']['Critical Value(5%)'] = t[4]['5%']
    result['value']['Critical Value(10%)'] = t[4]['10%']
    return result

#使用ADF单位根检验法，检验时间序列的稳定性
adf_Data = ts.adfuller(data.value)
#解读 ADF 单位根检验法得到的结果
adfResult = tagADF(adf_Data)

#对数据进行差分，
#因为差分之后，第一个位置会有一个空值
#所以调用 dropna 方法删掉它
diff = data.value.diff(1).dropna()

plt.figure()
plt.plot(diff, 'r')


#使用ADF单位根检验法，检验时间序列的稳定性
adfDiff = ts.adfuller(diff)
#解读 ADF 单位根检验法得到的结果
adfResult = tagADF(adfDiff)

#使用 AR 建模
arModel = sm.tsa.AR(
    diff
)

#使用 AR 模型的 select_order 方法
#自动根据 AIC 指标，选择最优的 p 值
p = arModel.select_order(
    maxlag=30, 
    ic='aic'
)
p

#使用最优的 p 值进行建模
arModel = arModel.fit(maxlag=p)

#对时间序列模型进行评估
delta = arModel.fittedvalues - diff
score = 1 - delta.var()/diff.var()
print(score)


"""
from sklearn.externals import joblib
joblib.dump(ic, 'ic.var')
ic = joblib.load('ic.var')
"""

#ARMA模型，使用AIC指标
#AR模型从1-15中选择最优的p
#MA模型从1-15中选择最优的q
#执行时间非常长，作者执行了10个小时左右
ic = sm.tsa.arma_order_select_ic(
    diff, 
    max_ar=15, 
    max_ma=15, 
    ic='aic'
)
#选择最优参数
order = (6, 6)

armaModel = sm.tsa.ARMA(
    diff, order
).fit()
#评估模型得分
delta = armaModel.fittedvalues - diff
score = 1 - delta.var()/diff.var()
print(score)

#预测接下来10天的值
p = armaModel.predict(
    start='2016-03-31', 
    end='2016-04-10'
)

#封装一个对差分的数据进行还原的函数
def revert(diffValues, *lastValue):
    for i in range(len(lastValue)):
        result = []
        lv = lastValue[i]
        for dv in diffValues:
            lv = dv + lv
            result.append(lv)
        diffValues = result
    return diffValues

#对差分的数据进行还原
r = revert(p, 10395)


plt.figure()
plt.plot(
    diff, 'r', 
    label='Raw'
)
plt.plot(
    armaModel.fittedvalues, 'g',
    label='ARMA Model'
)
plt.plot(
    p, 'b', label='ARMA Predict'
)
plt.legend()

r = pandas.DataFrame({
    'value': r
  }, index=p.index
)
plt.figure()
plt.plot(
    data.value, c='r', 
    label='Raw'
)
plt.plot(
    r, c='g',
    label='ARMA Model'
)
plt.legend()
