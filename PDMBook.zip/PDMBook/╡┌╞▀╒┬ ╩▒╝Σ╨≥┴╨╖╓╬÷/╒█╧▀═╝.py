# -*- coding: utf-8 -*-

import pandas
from matplotlib import pyplot as plt
import matplotlib.font_manager as font_manager

fontProp = font_manager.FontProperties(
    'font.otf'
)

data = pandas.read_csv(
    '折线图.csv'
)

#对日期格式进行转换
data['购买日期'] = pandas.to_datetime(
    data['日期']
)

mainColor = (42/256, 87/256, 141/256, 1);
plt.figure()

plt.xlabel(
    '购买日期', 
    color=mainColor,
    fontproperties=fontProp
)
plt.ylabel(
    '购买用户数', 
    color=mainColor,
    fontproperties=fontProp
)
plt.tick_params(
    axis='x', 
    colors=mainColor
)
plt.tick_params(
    axis='y', 
    colors=mainColor
)

#'-'	顺滑的曲线
plt.plot(
    data['购买日期'], 
    data['购买用户数'], 
    '-', 
    color=mainColor
)

plt.title(
    '购买用户数',
    fontproperties=fontProp
)
plt.show()


plt.title('购买用户数')
plt.xlabel('购买日期', color=mainColor)
plt.ylabel('购买用户数', color=mainColor)
plt.tick_params(axis='x', colors=mainColor)
plt.tick_params(axis='y', colors=mainColor)
#设置线条粗细
plt.plot(
    data['购买日期'], 
    data['购买用户数'], 
    '-', 
    color=mainColor, 
    lineWidth=10
)
plt.show()



#设置子图
fig, ax1 = plt.subplots()
#左边纵轴绘制购买用户数
plt.title('销售情况')
ax1.set_xlabel('购买日期', color=mainColor)
ax1.set_ylabel('购买用户数', color=mainColor)
ax1.tick_params(axis='x', colors=mainColor)
ax1.tick_params(axis='y', colors=mainColor)
p1 = ax1.plot(
    data['购买日期'], data['购买用户数'], 
    '-', color='blue'
)
#右边纵轴绘制广告费用和渠道数
ax2 = ax1.twinx()
ax2.set_ylabel('广告费用', color=mainColor)
ax2.tick_params(axis='y', colors=mainColor)
p2 = ax2.plot(
    data['购买日期'], data['广告费用'], 
    '-', color='red'
)
'''
p3 = ax2.plot(
    data['购买日期'], data['渠道数'], 
    '-', color='green'
)
'''
#设置图例
ps = p1 + p2 #+ p3
labs = ['购买用户数', '广告费用']
ax1.legend(
    ps, labs, loc=2
)
plt.show()
