# -*- coding: utf-8 -*-
import pandas

data = pandas.read_csv(
    "D:\\PDMBook\\第六章 关联\\超市销售数据.csv",
    encoding='utf8', engine='python'
)
#根据单据号，
#分组统计每个购物篮中的商品列表
itemSetList = data.groupby(
    by='单据号'
).apply(
    lambda x: list(x.商品名称)
)
#根据单据号，
#分组统计每个购物篮中的商品数量
itemSetCount = itemSet = data.groupby(
    by='单据号'
).apply(
    lambda x: len(x.商品名称)
)
#将统计数据汇总为一个数据框
itemSet = pandas.DataFrame({
    '商品列表': itemSetList, 
    '商品数量': itemSetCount
})
#过滤出商品数量大于1的购物篮
itemSet = itemSet[itemSet.商品数量>1]

#获取到购物篮中的商品列表，用于apriori函数的输入
transactions = itemSet['商品列表'].values

from apyori import apriori
#调用apriori算法进行计算，
#得到关联规则和与之对应的统计指标
results = list(
    apriori(
        transactions, 
        min_support=0.001, 
        min_confidence=0.001, 
        min_lift=1.001
    )
)

#支持度（support）
supports = []
#自信度（confidence）
confidences = []
#提升度（lift）
lifts = []
#基于项items_base
bases = []
#推导项items_add
adds = []

#把apriori函数计算的结果，
#保存成为一个数据框，方便数据分析
for r in results:
    size = len(r.ordered_statistics)
    for j in range(size):
        supports.append(r.support)
        confidences.append(
            r.ordered_statistics[j].confidence
        )
        lifts.append(r.ordered_statistics[j].lift)
        bases.append(
            list(r.ordered_statistics[j].items_base)
        )
        adds.append(
            list(r.ordered_statistics[j].items_add)
        )
#保存成为一个数据框
result = pandas.DataFrame({
    '基于': bases,
    '推荐': adds,
    '支持度': supports,
    '自信度': confidences,
    '提升度': lifts
})
