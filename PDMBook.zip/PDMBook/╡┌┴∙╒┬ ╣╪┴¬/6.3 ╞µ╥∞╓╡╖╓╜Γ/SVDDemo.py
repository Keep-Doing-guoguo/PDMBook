import numpy

#用户对商品的评分矩阵
ratings = numpy.mat([
    [5, 0, 3, 0, 1],
    [0, 6, 0, 4, 2],
    [5, 0, 3, 0, 1]
])

#使用SVD算法分解矩阵
U, S, V = numpy.linalg.svd(
    ratings, full_matrices=True
)
#输出S
S
#因为特征值只有两个大于0，
#所以设置r=2
U
U[:, :2]
S
numpy.diag(S)[:2,:2]
V
V[:2, :]
#重新计算新的评分矩阵
numpy.dot(
    numpy.dot(
        U[:, :2], 
        numpy.diag(S)[:2,:2]
    ), 
    V[:2, :]
)

S = numpy.array([8.39939489, 7.44648679, 0., 0.0, 0.0])
uRating = [5, 0, 3, 0, 1]

numpy.dot(     
    numpy.dot(uRating, numpy.diag(S)),
    V
)


import pandas

ratings = pandas.read_csv(
    "D:\\PDMBook\\第六章 关联\\6.3 奇异值分解\\u.data", 
    sep='\t', names=["UserID", "ItemID", "rating", "timestamp"]
)

from surprise import Reader
from surprise import Dataset

reader = Reader(
    rating_scale=(1, 5)
)

ratingDataSet = Dataset.load_from_df(
    ratings[['UserID', 'ItemID', 'rating']], 
    reader
)

from surprise import SVD
#基于用户的协同推荐算法
userBased = SVD(
    n_factors=20
) 
#从DataSet中调用build_full_trainset方法生成训练样本
trainSet = ratingDataSet.build_full_trainset()
#使用所有训练样本训练模型
userBased.fit(trainSet)

#目标用户ID
uid = 196

#获取 uid 对应的所有 iid
hasItemIDs = ratings[
    ratings.UserID==uid
].ItemID.drop_duplicates().values

#获取所有的 iid
allItemIDs = ratings.ItemID.drop_duplicates()

#保存 没有的 iid 的预测评分
_iids = []
_ratings = []
for iid in allItemIDs:
    if iid not in hasItemIDs:
        _iids.append(iid)
        #调用模型的predict方法，预测uid对iid的评分
        _ratings.append(
            userBased.predict(uid, iid).est
        )        
#将结果以数据框的形式返回
result = pandas.DataFrame({
    'iid': _iids,
    'rating': _ratings
})
