# -*- coding: utf-8 -*-
import pandas

data = pandas.read_csv(
    "data.csv",
    encoding='utf8', engine='python'
)

transactions = data.groupby(by='单据号').apply(
    lambda x: list(x.商品名称)
)

from mlxtend.preprocessing import TransactionEncoder

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)

df = pandas.DataFrame(te_ary, columns=te.columns_)
df

from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

frequent_itemsets = apriori(
    df, 
    min_support=0.001, 
    use_colnames=True
)

results = list(
    apriori(
        transactions, 
        min_support=0.001, 
        min_confidence=0.05, 
        min_lift=1
    )
)

#支持度（support）
supports = []
#自信度（confidence）
confidences = []
#提升度（lift）
lifts = []
#基于项items_base
bases = []
#推导项items_add
adds = []

for r in results:
    size = len(r.ordered_statistics)
    for j in range(size):
        supports.append(r.support)
        confidences.append(r.ordered_statistics[j].confidence)
        lifts.append(r.ordered_statistics[j].lift)
        bases.append(list(r.ordered_statistics[j].items_base))
        adds.append(list(r.ordered_statistics[j].items_add))

result = pandas.DataFrame({
    '基于': bases,
    '推荐': adds,
    '支持度': supports,
    '自信度': confidences,
    '提升度': lifts
})

r = result[
    (result.提升度>1) 
    & (result.支持度>0.1) 
    & (result.自信度>1)
]
