# -*- coding: utf-8 -*-

import pandas
#读取数据到 data 变量中
data = pandas.read_csv(
    'D:\\PDMBook\\第四章 特征工程\\4.4 缺失值处理\\缺失值.csv', 
    encoding='utf8', 
    engine='python'
)

#直接删除缺失值
dropNaData = data.dropna()

from sklearn.preprocessing import Imputer

imputer = Imputer(strategy='mean')
#均值填充缺失值
data['年龄_Imputer'] = imputer.fit_transform(data[['年龄']])
data['工资_Imputer'] = imputer.fit_transform(data[['工资']])

#模型填充
#先处理年龄的缺失值，
#因此把另外一列中存在缺失值的工资列的缺失值删掉
data_predict_年龄 = data.dropna(subset=["工资"])

#找出剩下数据中，年龄缺失值所在位置
年龄NA_index = data_predict_年龄.年龄.isna()

#拿到训练数据和预测数据
data_predict_年龄_fit = data_predict_年龄[~年龄NA_index]
data_predict_年龄_predict = data_predict_年龄[年龄NA_index]

#开始使用线性回归建模
from sklearn.preprocessing import OneHotEncoder

#对训练数据进行特征处理
oneHotEncoder = OneHotEncoder()
oneHotData_fit = oneHotEncoder.fit_transform(
    data_predict_年龄_fit[['国家', '购买']]
)
from scipy.sparse import hstack
#将独热编码所得的数据，和工资合并在一起
x_fit = hstack([
    oneHotData_fit, 
    data_predict_年龄_fit.工资.values.reshape(-1, 1)
])
y_fit = data_predict_年龄_fit['年龄']

#训练线性回归模型
from sklearn.linear_model import LinearRegression
linearRegression = LinearRegression()
linearRegression.fit(x_fit, y_fit)

#处理要预测的数据的特征
oneHotData_predict = oneHotEncoder.transform(
    data_predict_年龄_predict[['国家', '购买']]
)
x_predict = hstack([
    oneHotData_predict, 
    data_predict_年龄_predict.工资.values.reshape(-1, 1)
])
#预测缺失值
linearRegression.predict(x_predict)


