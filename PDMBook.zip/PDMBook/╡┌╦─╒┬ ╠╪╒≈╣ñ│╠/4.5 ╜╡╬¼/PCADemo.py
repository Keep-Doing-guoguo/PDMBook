from sklearn import datasets

iris = datasets.load_iris()

x = iris.data
y = iris.target

from sklearn.decomposition import PCA
pca = PCA(n_components=2)
x_2  = pca.fit_transform(x)

import matplotlib.pyplot as plt
plt.figure()
plt.scatter(x_2[:,0], x_2[:,1], c=y)

