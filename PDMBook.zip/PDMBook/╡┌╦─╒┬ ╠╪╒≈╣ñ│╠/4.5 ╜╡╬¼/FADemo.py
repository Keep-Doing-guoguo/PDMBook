import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第四章 特征工程\\4.5 降维\\fa.csv', 
    encoding='utf8', engine='python'
)

from sklearn.preprocessing import scale
from sklearn.decomposition import FactorAnalysis
fa = FactorAnalysis(n_components=2)
#进行因子分析之前，需要对数据进行标准化
faData  = fa.fit_transform(scale(data))

#获取因子的载荷矩阵
loadingVSK = pandas.DataFrame({
    "PA1": fa.components_[0],
    "PA2": fa.components_[1]
})
#把列名添加到载荷矩阵的数据框中
loadingVSK['colName'] = data.columns.values

import matplotlib
import matplotlib.pyplot as plt
#字体
font = matplotlib.font_manager.FontProperties(
    fname='D:\\PDMBook\\SourceHanSansCN-Light.otf', 
    size=30
)

fig = plt.figure()

#画出原点坐标轴
plt.axvline(x=0, linewidth=1)
plt.axhline(y=0, linewidth=1)

#解决符号是乱码的问题
#matplotlib.rcParams['axes.unicode_minus'] = False 
plt.rcParams['axes.unicode_minus']=False
plt.scatter(
    loadingVSK['PA1'], 
    loadingVSK['PA2']
)
loadingVSK.apply(
    lambda row: plt.text(
        row.PA1, row.PA2, 
        row.colName, fontproperties=font
    ), axis=1
)
#第一个因子的贡献度
sum(loadingVSK['PA1']**2)/6
#第二个因子的贡献度
sum(loadingVSK['PA2']**2)/6
#两个因子加起来的贡献度
sum(loadingVSK['PA1']**2)/6+sum(loadingVSK['PA2']**2)/6

data['硬件评价'] = faData[:, 0]
data['软件评价'] = faData[:, 1]

plt.scatter(faData[:, 0], faData[:, 1])
