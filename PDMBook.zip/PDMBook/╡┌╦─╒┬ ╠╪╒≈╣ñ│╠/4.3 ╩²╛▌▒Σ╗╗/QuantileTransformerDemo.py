import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第四章 特征工程\\4.3 数据变换\\华南地区.csv',
    engine='python', encoding='utf8'
)

data['注册时长_cut'] = pandas.qcut(
    data.注册时长, 10
)
data['营收收入_cut'] = pandas.qcut(
    data.营收收入, 10
)
data['成本_cut'] = pandas.qcut(
    data.成本, 10
)

data.groupby('注册时长_cut')['ID'].count()

data.groupby('营收收入_cut')['ID'].count()

data.groupby('成本_cut')['ID'].count()

from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection  import cross_val_score

#特征变量
x = data[['注册时长', '营收收入', '成本']]
#目标变量
y = data['是否续约']

gaussianNB = GaussianNB()
cross_val_score(
    gaussianNB,
    x, y, cv=3, 
).mean()

cutX = data[[
    '注册时长_cut', 
    '营收收入_cut', 
    '成本_cut'
]]

from sklearn.preprocessing import OneHotEncoder
#新建独热编码器
oneHotEncoder = OneHotEncoder()
#训练独热编码器，得到转换规则
oneHotEncoder.fit(
    cutX.astype(str)
)
#转换数据
ohX = oneHotEncoder.transform(
    cutX.astype(str)
)

from sklearn.naive_bayes import BernoulliNB
bernoulliNB = BernoulliNB()
cross_val_score(
    bernoulliNB,
    ohX, y, cv=3, 
).mean()
