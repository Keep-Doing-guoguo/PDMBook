import pandas

data = pandas.read_csv(
    'D:\\PDMBook\\第四章 特征工程\\4.3 数据变换\\华南地区.csv',
    engine='python', encoding='utf8'
)

#特征变量
x = data[['注册时长', '营收收入', '成本']]
#目标变量
y = data['是否续约']

from sklearn.preprocessing import PowerTransformer

powerTransformer = PowerTransformer()
powerTransformer.fit(x)
px = powerTransformer.transform(x)

from sklearn.naive_bayes import GaussianNB
from sklearn.model_selection  import cross_val_score

gaussianNB = GaussianNB()
cross_val_score(
    gaussianNB,
    x, y, cv=3, 
).mean()

gaussianNB2 = GaussianNB()
cross_val_score(
    gaussianNB2,
    px, y, cv=3, 
).mean()
