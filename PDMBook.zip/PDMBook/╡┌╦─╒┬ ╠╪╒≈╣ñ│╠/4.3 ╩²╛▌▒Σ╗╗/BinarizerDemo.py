from sklearn.datasets  import load_digits
#加载手写数字案例数据
mnist = load_digits()

import numpy
#拿第一个样本出来演示
digitData = numpy.reshape(
    mnist.data[0], 
    (8, 8)
)

from sklearn.preprocessing import Binarizer
#生成标准化对象
binarizer = Binarizer(threshold=0)
#把数据转换为标准化数据
binarizerData = binarizer.fit_transform(mnist.data)

import numpy
#拿第一个样本出来演示
digitBZData = numpy.reshape(
    binarizerData[0], 
    (8, 8)
)


from sklearn.naive_bayes import GaussianNB
from sklearn.naive_bayes import BernoulliNB
from sklearn.model_selection  import cross_val_score

gaussianNB = GaussianNB()
cross_val_score(
    gaussianNB,
    mnist.data, mnist.target, cv=3, 
).mean()

bernoulliNB = BernoulliNB()
cross_val_score(
    bernoulliNB,
    binarizerData, mnist.target, cv=3, 
).mean()
