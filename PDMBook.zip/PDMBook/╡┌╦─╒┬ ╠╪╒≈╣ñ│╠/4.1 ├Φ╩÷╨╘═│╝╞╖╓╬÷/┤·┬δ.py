import pandas

data = pandas.read_csv(
    "描述性统计分析.csv",
    encoding='utf8', engine='python'
)

data.注册时长.describe()

data.注册时长.hist()